import React from 'react';
import ReactDOM from 'react-dom/client';
import Template from '../template/index.jsx';
import { CustomProvider, scopeVars } from '../_shared/CustomContext.jsx';
import { customTokensCss } from '../_shared/brand.js';
import { startSmoothScroll } from '../_shared/smoothScroll.js';
// Brand name, colours (primaryColor/accentColor), fontPair, currency, contactEmail,
// instagramUrl, images and productNames — edit this file to re-brand the site.
import custom from './custom.json';

// The template declares its colour tokens on its own root, so customised values
// are re-asserted there.
const tokens = customTokensCss('design-08-ecommerce', custom, 'coffee');
if (tokens) {
  const style = document.createElement('style');
  style.textContent = tokens;
  document.head.appendChild(style);
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <div className="tpl-scope tpl-design-08-ecommerce" style={scopeVars(custom)}>
      <CustomProvider value={custom}><Template /></CustomProvider>
    </div>
  </React.StrictMode>
);

// Inertial wheel scrolling keeps scrubbed and pinned sections in lockstep with the scroll.
startSmoothScroll();
